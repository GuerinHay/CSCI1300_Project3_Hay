

How to compile and run:
g++ -std=c++17 map.cpp weapon.cpp monster.cpp party.cpp partyMember.cpp  merchant.cpp DungeonEscape.cpp mainGame.cpp


Dependencies:
All .h files must be in the same directory to run.

Submission information:

CSCI1300 Spring 2023 Project 3
Author: Guerin Hay
Recitation: 107 - Tanmay Desai
Date: Apr 30, 2023

